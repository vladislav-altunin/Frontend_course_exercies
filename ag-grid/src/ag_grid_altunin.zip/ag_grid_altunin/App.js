import './App.css';
import TodoInput from './TodoInput';

function App() {
  return (
    <div className="App">
      <TodoInput />
    </div>
  );
}

export default App;
